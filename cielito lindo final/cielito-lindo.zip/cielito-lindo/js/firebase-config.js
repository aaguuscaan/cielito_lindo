// ============================================================
// FIREBASE CONFIGURATION - Cielito Lindo
// Reemplazá estos valores con los de tu proyecto Firebase
// ============================================================

const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "TU_PROJECT.firebaseapp.com",
  projectId: "TU_PROJECT_ID",
  storageBucket: "TU_PROJECT.appspot.com",
  messagingSenderId: "TU_SENDER_ID",
  appId: "TU_APP_ID"
};

// Inicializar Firebase
firebase.initializeApp(firebaseConfig);

// Exportar servicios
const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage();

// ============================================================
// DATOS INICIALES - ejecutar UNA VEZ para seedear Firestore
// ============================================================
async function seedInitialData() {
  // Verificar si ya existe la cabaña
  const cabinRef = db.collection('cabins').doc('cielito-lindo');
  const cabinDoc = await cabinRef.get();

  if (!cabinDoc.exists) {
    await cabinRef.set({
      nombre: 'Cielito Lindo',
      descripcion: 'Una cabaña de montaña diseñada para reconectar con lo esencial. Rodeada de naturaleza, con vistas únicas a las Sierras de Córdoba. Cada detalle fue pensado para que tu estadía sea una experiencia memorable.',
      precio: 45000, // precio por noche en pesos
      capacidad: 6,
      servicios: ['WiFi', 'Pileta', 'Asador', 'Cocina Equipada', 'Estacionamiento', 'Aire Acondicionado', 'Calefacción', 'Smart TV', 'Vista a las Sierras'],
      imagenes: [],
      ubicacion: 'Villa Yacanto, Córdoba, Argentina',
      lat: -32.0874,
      lng: -64.8597,
      whatsapp: '5493511234567',
      activa: true,
      creadoEn: firebase.firestore.FieldValue.serverTimestamp()
    });
    console.log('✅ Cabaña creada');
  }
}

// Reglas de Firestore sugeridas (agregar en Firebase Console):
/*
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /cabins/{cabinId} {
      allow read: if true;
      allow write: if request.auth != null && get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    match /bookings/{bookingId} {
      allow read: if request.auth != null && (resource.data.userId == request.auth.uid || get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin');
      allow create: if request.auth != null;
      allow update, delete: if request.auth != null && get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      allow read: if request.auth != null && get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    match /reviews/{reviewId} {
      allow read: if true;
      allow create: if request.auth != null;
      allow update, delete: if request.auth != null && (resource.data.userId == request.auth.uid || get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin');
    }
  }
}
*/
